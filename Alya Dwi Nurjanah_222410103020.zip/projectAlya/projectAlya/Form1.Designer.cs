﻿namespace projectAlya
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.roleHeroBox = new System.Windows.Forms.TextBox();
            this.namaHeroBox = new System.Windows.Forms.TextBox();
            this.damageHeroBox = new System.Windows.Forms.TextBox();
            this.expLaneButton = new System.Windows.Forms.RadioButton();
            this.midLaneButton = new System.Windows.Forms.RadioButton();
            this.goldLaneButton = new System.Windows.Forms.RadioButton();
            this.emblemHero = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.createButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.readButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.idHeroText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(259, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "PICK YOUR HERO";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Role Hero";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nama Hero";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Damage Hero";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Lane Hero";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Emblem Hero";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roleHeroBox
            // 
            this.roleHeroBox.Location = new System.Drawing.Point(162, 124);
            this.roleHeroBox.Name = "roleHeroBox";
            this.roleHeroBox.Size = new System.Drawing.Size(156, 22);
            this.roleHeroBox.TabIndex = 6;
            // 
            // namaHeroBox
            // 
            this.namaHeroBox.Location = new System.Drawing.Point(162, 166);
            this.namaHeroBox.Name = "namaHeroBox";
            this.namaHeroBox.Size = new System.Drawing.Size(156, 22);
            this.namaHeroBox.TabIndex = 7;
            // 
            // damageHeroBox
            // 
            this.damageHeroBox.Location = new System.Drawing.Point(162, 198);
            this.damageHeroBox.Name = "damageHeroBox";
            this.damageHeroBox.Size = new System.Drawing.Size(156, 22);
            this.damageHeroBox.TabIndex = 8;
            // 
            // expLaneButton
            // 
            this.expLaneButton.AutoSize = true;
            this.expLaneButton.Location = new System.Drawing.Point(162, 233);
            this.expLaneButton.Name = "expLaneButton";
            this.expLaneButton.Size = new System.Drawing.Size(84, 20);
            this.expLaneButton.TabIndex = 9;
            this.expLaneButton.TabStop = true;
            this.expLaneButton.Text = "Exp Lane";
            this.expLaneButton.UseVisualStyleBackColor = true;
            // 
            // midLaneButton
            // 
            this.midLaneButton.AutoSize = true;
            this.midLaneButton.Location = new System.Drawing.Point(162, 268);
            this.midLaneButton.Name = "midLaneButton";
            this.midLaneButton.Size = new System.Drawing.Size(83, 20);
            this.midLaneButton.TabIndex = 10;
            this.midLaneButton.TabStop = true;
            this.midLaneButton.Text = "Mid Lane";
            this.midLaneButton.UseVisualStyleBackColor = true;
            // 
            // goldLaneButton
            // 
            this.goldLaneButton.AutoSize = true;
            this.goldLaneButton.Location = new System.Drawing.Point(162, 304);
            this.goldLaneButton.Name = "goldLaneButton";
            this.goldLaneButton.Size = new System.Drawing.Size(90, 20);
            this.goldLaneButton.TabIndex = 11;
            this.goldLaneButton.TabStop = true;
            this.goldLaneButton.Text = "Gold Lane";
            this.goldLaneButton.UseVisualStyleBackColor = true;
            // 
            // emblemHero
            // 
            this.emblemHero.FormattingEnabled = true;
            this.emblemHero.Items.AddRange(new object[] {
            "Tank",
            "Assasin",
            "Mage",
            "Fighter",
            "Support"});
            this.emblemHero.Location = new System.Drawing.Point(162, 339);
            this.emblemHero.Name = "emblemHero";
            this.emblemHero.Size = new System.Drawing.Size(156, 24);
            this.emblemHero.TabIndex = 12;
            this.emblemHero.SelectedValueChanged += new System.EventHandler(this.emblemHero_SelectedValueChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Aqua;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(350, 94);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(500, 337);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.Layout += new System.Windows.Forms.LayoutEventHandler(this.dataGridView1_Layout);
            // 
            // createButton
            // 
            this.createButton.Location = new System.Drawing.Point(162, 379);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(75, 23);
            this.createButton.TabIndex = 14;
            this.createButton.Text = "Create";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(162, 408);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(75, 23);
            this.updateButton.TabIndex = 15;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // readButton
            // 
            this.readButton.Location = new System.Drawing.Point(243, 379);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(75, 23);
            this.readButton.TabIndex = 16;
            this.readButton.Text = "Read";
            this.readButton.UseVisualStyleBackColor = true;
            this.readButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(243, 408);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(75, 23);
            this.deleteButton.TabIndex = 17;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // idHeroText
            // 
            this.idHeroText.Location = new System.Drawing.Point(162, 89);
            this.idHeroText.Name = "idHeroText";
            this.idHeroText.Size = new System.Drawing.Size(156, 22);
            this.idHeroText.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(32, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 18;
            this.label7.Text = "ID Hero";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 450);
            this.Controls.Add(this.idHeroText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.readButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.createButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.emblemHero);
            this.Controls.Add(this.goldLaneButton);
            this.Controls.Add(this.midLaneButton);
            this.Controls.Add(this.expLaneButton);
            this.Controls.Add(this.damageHeroBox);
            this.Controls.Add(this.namaHeroBox);
            this.Controls.Add(this.roleHeroBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Hero";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox roleHeroBox;
        private System.Windows.Forms.TextBox namaHeroBox;
        private System.Windows.Forms.TextBox damageHeroBox;
        private System.Windows.Forms.RadioButton expLaneButton;
        private System.Windows.Forms.RadioButton midLaneButton;
        private System.Windows.Forms.RadioButton goldLaneButton;
        private System.Windows.Forms.ComboBox emblemHero;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button readButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.TextBox idHeroText;
        private System.Windows.Forms.Label label7;
    }
}

