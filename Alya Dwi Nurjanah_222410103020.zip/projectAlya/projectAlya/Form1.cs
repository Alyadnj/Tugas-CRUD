﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace projectAlya
{
    public partial class Form1 : Form
    {
        private string connString = "Server=localhost; Port=5432; User Id=postgres; Password=220305; Database=postgres";
        private NpgsqlConnection conn;
        private string sql;
        private NpgsqlCommand cmd;
        private DataTable dt;
        string laneHeroPick;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new NpgsqlConnection(connString);
            Select();
        }

        private void Select()
        {
            try
            {
                conn.Open();
                sql = @"select * from Hero";
                cmd = new NpgsqlCommand(sql, conn);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                conn.Close();
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void label1_Resize(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void emblemHero_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(expLaneButton.Checked == true)
            {
                laneHeroPick = "Exp Lane";
            }
            else if (midLaneButton.Checked == true)
            {
                laneHeroPick = "Mid Lane";
            }
            else
            {
                laneHeroPick = "Gold Lane";
            }

            conn.Open();
            string q = @"insert into Hero (idHERO, roleHERO, namaHERO, damageHERO, laneHERO, emblemHERO) values ('"+idHeroText.Text+ "','"+roleHeroBox.Text+ "','" + namaHeroBox.Text + "','" + damageHeroBox.Text + "','" + laneHeroPick + "','" + emblemHero.SelectedItem + "')";
            cmd = new NpgsqlCommand(q, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data berhasil ditambahkan");
            conn.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            sql = @"select * from Hero";
            cmd = new NpgsqlCommand(sql, conn);
            dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            conn.Close();
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            conn.Open();
            string updt = @"update Hero set namaHERO='" + roleHeroBox.Text + "' where namaHERO='" + namaHeroBox.Text + "'";
            cmd = new NpgsqlCommand(updt, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Data berhasil di update");
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            conn.Open();
            string d = @"delete from Hero where namaHERO = '" + namaHeroBox.Text + "'";
            cmd = new NpgsqlCommand(d, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Data berhasil dihapus");
        }
    }
}
